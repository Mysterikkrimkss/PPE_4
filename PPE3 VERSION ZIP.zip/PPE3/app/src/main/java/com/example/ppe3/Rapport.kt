package com.example.ppe3

import java.util.*
import kotlin.concurrent.timer

class Rapport (
    val id: String, val motif: String, val bilan: String, val echan: String, val praticien: String){
    constructor():this("", "", "", "", ""){}



    //,    val date: TimeZone, val date2: TimeZone
    //, date2 = TimeZone.getDefault(), date = TimeZone.getDefault()


}
