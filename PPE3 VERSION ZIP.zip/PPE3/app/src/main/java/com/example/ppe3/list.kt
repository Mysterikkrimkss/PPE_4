package com.example.ppe3

class list(val blian : String,val ehan : String,val motif: String,val praticien : String) {
    constructor() : this("","","","")

    override fun toString(): String {
        return motif
    }
}